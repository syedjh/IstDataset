<?php

namespace Drupal\dataset_upload\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

class SettingsForm extends ConfigFormBase {
  protected function getEditableConfigNames() {
    return ['dataset_upload.settings'];
  }

  public function getFormId() {
    return 'dataset_upload_settings_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('dataset_upload.settings');
    $form['openai_api_key'] = [
      '#type' => 'textfield',
      '#title' => $this->t('OpenAI API Key'),
      '#default_value' => $config->get('openai_api_key'),
      '#required' => TRUE,
    ];
    return parent::buildForm($form, $form_state);
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->config('dataset_upload.settings')
      ->set('openai_api_key', $form_state->getValue('openai_api_key'))
      ->save();
    parent::submitForm($form, $form_state);
  }
}
