<?php

namespace Drupal\dataset_upload\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\dataset_upload\Service\FileParserService;
use Drupal\file\Entity\File;
use Drupal\dataset_upload\Entity\DatasetMetadata;
use Drupal\dropzonejs\Element\DropzoneJs;


class DatasetUploadForm extends FormBase {

  protected $fileParser;

  public function __construct(FileParserService $fileParser) {
    $this->fileParser = $fileParser;
  }

  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('dataset_upload.file_parser')
    );
  }

  public function getFormId() {
    return 'dataset_upload_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {

    if ($summary = $form_state->get('summary')) {
      $form['summary'] = [
        '#theme' => 'dataset_summary',
        '#summary' => $summary,
        '#weight' => 100,
      ];
    }

    $form['dataset_file'] = [
      '#type' => 'dropzonejs',
      '#title' => $this->t('Upload Dataset File'),
      '#description' => $this->t('Upload a CSV or XLSX file (max 5MB).'),
      '#dropzone_description' => $this->t('Drag and drop your CSV or XLSX file here'),
      '#extensions' => 'csv xlsx',
      '#upload_validators' => [
        'file_validate_extensions' => ['csv xlsx'],
        'file_validate_size' => [5 * 1024 * 1024],
      ],
      '#upload_location' => 'public://datasets/',
      '#multiple' => FALSE,
    ];


    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Upload and Process'),
    ];

    $form['#attributes']['enctype'] = 'multipart/form-data';

    $form['#prefix'] = '<div class="dataset-upload-form-wrapper">';
    $form['#suffix'] = '</div>';
    $form['#attached']['library'][] = 'dataset_upload/form';

    return $form;
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Get the uploaded files array from DropzoneJS element.
    $uploaded_files = $form_state->getValue(['dataset_file', 'uploaded_files']);
    if (!empty($uploaded_files) && is_array($uploaded_files)) {
      // Only one file allowed, so take the first.
      $file_info = reset($uploaded_files);
      $file = NULL;

      if (!empty($file_info['fid'])) {
        $file = File::load($file_info['fid']);
      }
      elseif (!empty($file_info['path'])) {
        // Create a File entity from the uploaded file path.
        $file = File::create([
          'uri' => $file_info['path'],
          'status' => 0,
        ]);
        $file->save();
      }

      if ($file) {
        // Set file status to permanent.
        $file->setPermanent();
        $file->save();
        $file_uri = $file->getFileUri();
        $real_path = \Drupal::service('file_system')->realpath($file_uri);
        $summary = $this->fileParser->parse($file_uri);

        // Save metadata entity
        $metadata = DatasetMetadata::create([
          'file_name' => $summary['file_name'],
          'file_size' => $summary['file_size_kb'],
          'columns' => implode(', ', $summary['columns']),
          'rows' => $summary['rows'],
          'status' => 'uploaded',
        ]);
        $metadata->save();

        $form_state->set('summary', $summary);
        $form_state->setRebuild(TRUE);

      } else {
        \Drupal::messenger()->addError($this->t('Unable to load or create the uploaded file.'));
      }
    } else {
      \Drupal::messenger()->addError($this->t('File upload failed. Please select a file before submitting.'));
    }
  }
}
