<?php

namespace Drupal\dataset_upload\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\dataset_upload\Service\AIMetadataService;
use Drupal\dataset_upload\Entity\DatasetMetadata;

class MetadataEditorForm extends FormBase {

  protected $aiMetadata;

  public function __construct(AIMetadataService $aiMetadata) {
    $this->aiMetadata = $aiMetadata;
  }

  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('dataset_upload.ai_metadata')
    );
  }

  public function getFormId() {
    return 'dataset_metadata_editor_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state, $metadata_id = NULL) {
    $metadata = $metadata_id ? DatasetMetadata::load($metadata_id) : NULL;
    $languages = \Drupal::languageManager()->getLanguages();

    // Only use fields that exist on the entity.
    $entity_fields = $metadata ? $metadata->getFieldDefinitions() : [];

    foreach ($languages as $langcode => $language) {
      $translation = ($metadata && $metadata->hasTranslation($langcode))
        ? $metadata->getTranslation($langcode)
        : $metadata;

      // Safely get values only for fields that exist.
      $form['title'][$langcode] = [
        '#type' => 'textfield',
        '#title' => $this->t('Title (@lang)', ['@lang' => $language->getName()]),
        '#default_value' => ($translation && isset($entity_fields['title'])) ? $translation->get('title')->value : '',
      ];
      $form['description'][$langcode] = [
        '#type' => 'textarea',
        '#title' => $this->t('Description (@lang)', ['@lang' => $language->getName()]),
        '#default_value' => ($translation && isset($entity_fields['description'])) ? $translation->get('description')->value : '',
      ];
      $form['tags'][$langcode] = [
        '#type' => 'textfield',
        '#title' => $this->t('Tags (@lang)'),
        '#default_value' => ($translation && isset($entity_fields['tags'])) ? $translation->get('tags')->value : '',
        '#description' => $this->t('Comma-separated.'),
      ];
      $form['categories'][$langcode] = [
        '#type' => 'textfield',
        '#title' => $this->t('Categories (@lang)'),
        '#default_value' => ($translation && isset($entity_fields['categories'])) ? $translation->get('categories')->value : '',
        '#description' => $this->t('Comma-separated.'),
      ];
    }

    $form['actions'] = [
      '#type' => 'actions',
      'preview' => [
        '#type' => 'submit',
        '#value' => $this->t('Preview AI Metadata'),
        '#submit' => ['::previewMetadata'],
      ],
      'save' => [
        '#type' => 'submit',
        '#value' => $this->t('Save as Draft'),
      ],
      'publish' => [
        '#type' => 'submit',
        '#value' => $this->t('Publish'),
      ],
    ];

    return $form;
  }

  public function previewMetadata(array &$form, FormStateInterface $form_state) {
    // Example: Use sample rows from session or file.
    $sample_rows = $form_state->get('sample_rows') ?? [];
    $ai_result = $this->aiMetadata->generateMetadata($sample_rows);
    foreach ($ai_result as $langcode => $data) {
      foreach (['title', 'description', 'tags', 'categories'] as $field) {
        if (isset($data[$field])) {
          $form_state->setValue([$field, $langcode], is_array($data[$field]) ? implode(', ', $data[$field]) : $data[$field]);
        }
      }
    }
    $this->messenger()->addStatus($this->t('AI metadata preview loaded. If you do not see fields updated, check your sample data and API key.'));
    $form_state->setRebuild();
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $metadata_id = $form_state->getBuildInfo()['args'][0] ?? NULL;
    $metadata = $metadata_id ? DatasetMetadata::load($metadata_id) : DatasetMetadata::create();

    $languages = \Drupal::languageManager()->getLanguages();
    foreach ($languages as $langcode => $language) {
      if (!$metadata->hasTranslation($langcode)) {
        $metadata->addTranslation($langcode);
      }
      $translation = $metadata->getTranslation($langcode);
      foreach (['title', 'description', 'tags', 'categories'] as $field) {
        $value = $form_state->getValue([$field, $langcode]);
        if ($value !== NULL) {
          $translation->set($field, $value);
        }
      }
    }

    // Enable revision support.
    $metadata->setNewRevision(TRUE);
    $metadata->isDefaultRevision(TRUE);
    $metadata->save();

    $this->messenger()->addStatus($this->t('Metadata saved as draft (revision).'));

    // Redirect to the entity list after save.
    $form_state->setRedirect('dataset_upload.entity_list');
  }
}
