<?php

namespace Drupal\dataset_upload\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\dataset_upload\Entity\DatasetMetadata;
use Drupal\Core\Url;
use Drupal\Core\Link;

class EntityListController extends ControllerBase {

  public function view() {
    $header = [
      'id' => $this->t('ID'),
      'file_name' => $this->t('File Name'),
      'file_size' => $this->t('File Size (KB)'),
      'columns' => $this->t('Columns'),
      'rows' => $this->t('Rows'),
      'status' => $this->t('Status'),
      'operations' => $this->t('Operations'),
    ];

    $rows = [];
    $storage = \Drupal::entityTypeManager()->getStorage('dataset_metadata');
    $entities = $storage->loadMultiple();

    foreach ($entities as $entity) {
      $metadata_id = $entity->id();
      $edit_url = Url::fromRoute('dataset_upload.metadata_editor', ['metadata_id' => $metadata_id]);
      $edit_link = Link::fromTextAndUrl($this->t('Edit Metadata'), $edit_url)->toString();

      // Only show revision link if the route exists (safely).
      $revisions_link = '';
      try {
        $route_provider = \Drupal::service('router.route_provider');
        $route_provider->getRouteByName('entity.dataset_metadata.revision_overview');
        $revisions_url = Url::fromRoute('entity.dataset_metadata.revision_overview', ['dataset_metadata' => $metadata_id]);
        $revisions_link = ' | ' . Link::fromTextAndUrl($this->t('Revisions'), $revisions_url)->toString();
      }
      catch (\Exception $e) {
        // Route does not exist, do not show revisions link.
      }

      $rows[] = [
        'id' => $metadata_id,
        'file_name' => $entity->get('file_name')->value,
        'file_size' => $entity->get('file_size')->value,
        'columns' => $entity->get('columns')->value,
        'rows' => $entity->get('rows')->value,
        'status' => $entity->get('status')->value,
        'operations' => [
          'data' => [
            '#markup' => $edit_link . $revisions_link,
          ],
        ],
      ];
    }

    return [
      '#type' => 'table',
      '#header' => $header,
      '#rows' => $rows,
      '#empty' => $this->t('No dataset metadata found.'),
    ];
  }

}