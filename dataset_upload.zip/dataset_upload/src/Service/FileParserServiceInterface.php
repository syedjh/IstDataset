<?php

namespace Drupal\dataset_upload\Service;

interface FileParserServiceInterface {
  /**
   * Parse a dataset file and return summary info.
   *
   * @param string $uri
   *   The file URI.
   *
   * @return array
   *   Summary info.
   */
  public function parse($uri);
}
