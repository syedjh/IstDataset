<?php

namespace Drupal\dataset_upload\Service;

use Drupal\Core\File\FileSystemInterface;
use Drupal\Core\Messenger\MessengerInterface;

class FileParserService implements FileParserServiceInterface {

  protected $fileSystem;
  protected $messenger;

  public function __construct(FileSystemInterface $fileSystem, MessengerInterface $messenger) {
    $this->fileSystem = $fileSystem;
    $this->messenger = $messenger;
  }

  public function parse($uri) {
    $real_path = $this->fileSystem->realpath($uri);
    $info = pathinfo($real_path);
    $extension = strtolower($info['extension'] ?? '');

    $summary = [
      'file_name' => $info['basename'] ?? '',
      'file_size_kb' => is_file($real_path) ? round(filesize($real_path) / 1024, 2) : 0,
      'columns' => [],
      'rows' => 0,
    ];

    try {
      if ($extension === 'csv') {
        $handle = fopen($real_path, 'r');
        if ($handle) {
          $header = fgetcsv($handle);
          $summary['columns'] = $header ?: [];
          $row_count = 0;
          while (($row = fgetcsv($handle)) !== FALSE) {
            $row_count++;
            // Optionally, break after a certain number for preview performance.
            // if ($row_count > 10000) break;
          }
          fclose($handle);
          $summary['rows'] = $row_count;
        }
        else {
          $this->messenger->addError(t('Could not open the CSV file.'));
        }
      }
      elseif ($extension === 'xlsx') {
        // XLSX parsing using PhpSpreadsheet (streaming).
        if (!class_exists('\PhpOffice\PhpSpreadsheet\Reader\Xlsx')) {
          $this->messenger->addError(t('XLSX parsing requires PhpSpreadsheet library.'));
        }
        else {
          $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
          $reader->setReadDataOnly(true);
          $spreadsheet = $reader->load($real_path);
          $worksheet = $spreadsheet->getActiveSheet();
          $rows = $worksheet->toArray();
          if (!empty($rows)) {
            $summary['columns'] = $rows[0];
            $summary['rows'] = count($rows) - 1;
          }
        }
      }
      else {
        $this->messenger->addError(t('Unsupported file type.'));
      }
    }
    catch (\Exception $e) {
      $this->messenger->addError(t('Error parsing file: @msg', ['@msg' => $e->getMessage()]));
    }

    return $summary;
  }
}
