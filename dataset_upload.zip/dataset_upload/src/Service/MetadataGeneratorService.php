<?php

namespace Drupal\dataset_upload\Service;

use GuzzleHttp\ClientInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;

class MetadataGeneratorService {

  protected $httpClient;
  protected $logger;

  public function __construct(ClientInterface $http_client, LoggerChannelFactoryInterface $logger_factory) {
    $this->httpClient = $http_client;
    $this->logger = $logger_factory->get('dataset_upload');
  }

  /**
   * Generate metadata from a dataset sample using OpenAI.
   */
  public function generateMetadata(array $sample_rows): array {
    $sample_text = $this->convertSampleToText($sample_rows);

    try {
      $response = $this->httpClient->post('https://api.openai.com/v1/chat/completions', [
        'headers' => [
          'Authorization' => 'Bearer YOUR_OPENAI_API_KEY',
          'Content-Type' => 'application/json',
        ],
        'json' => [
          'model' => 'gpt-3.5-turbo',
          'messages' => [
            [
              'role' => 'user',
              'content' => "Given this dataset sample, generate a title, short description, 3 tags, and 2 suggested categories. Return JSON.

Sample:
" . $sample_text,
            ],
          ],
        ],
      ]);

      $data = json_decode($response->getBody(), TRUE);
      $reply = $data['choices'][0]['message']['content'] ?? '{}';
      return json_decode($reply, TRUE);
    }
    catch (\Exception $e) {
      $this->logger->error('OpenAI metadata generation failed: @message', ['@message' => $e->getMessage()]);
      return [];
    }
  }

  /**
   * Convert array rows into text string for prompt.
   */
  protected function convertSampleToText(array $rows): string {
    $lines = [];
    foreach ($rows as $row) {
      $lines[] = implode(", ", $row);
    }
    return implode("\n", $lines);
  }
}
