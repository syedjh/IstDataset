<?php

namespace Drupal\dataset_upload\Service;

use GuzzleHttp\ClientInterface;
use Drupal\Core\Config\ConfigFactoryInterface;

class AIMetadataService {

  protected $httpClient;
  protected $config;

  public function __construct(ClientInterface $http_client, ConfigFactoryInterface $config_factory) {
    $this->httpClient = $http_client;
    $this->config = $config_factory->get('dataset_upload.settings');
  }

  /**
   * Generate metadata in English and Arabic.
   */
  public function generateMetadata(array $sample_rows): array {
    $sample_text = $this->convertSampleToText($sample_rows);
    $prompts = [
      'en' => "Given this dataset sample, generate a title, short description, 3 tags, and 2 suggested categories. Return JSON.",
      'ar' => "بالنظر إلى عينة البيانات هذه، أنشئ عنوانًا ووصفًا قصيرًا و3 وسوم و2 من الفئات المقترحة. أرجع النتيجة بصيغة JSON."
    ];
    $results = [];
    foreach ($prompts as $langcode => $prompt) {
      $results[$langcode] = $this->callOpenAI($prompt . "\n\nSample:\n" . $sample_text);
    }
    return $results;
  }

  protected function callOpenAI($prompt) {
    try {
      $api_key = $this->config->get('openai_api_key');
      if (empty($api_key)) {
        \Drupal::logger('dataset_upload')->error('OpenAI API key is missing. Set it at /admin/config/dataset-upload/settings.');
        return ['error' => 'OpenAI API key is missing.'];
      }
      $api_key = trim($api_key);
      if (strpos($api_key, 'sk-') !== 0) {
        \Drupal::logger('dataset_upload')->error('OpenAI API key format is invalid. It should start with "sk-".');
        return ['error' => 'OpenAI API key format is invalid.'];
      }
      if (strpos($api_key, 'sk-proj-') === 0) {
        \Drupal::logger('dataset_upload')->error('OpenAI project API keys (sk-proj-...) are not supported for API access. Use a personal API key from https://platform.openai.com/api-keys.');
        return ['error' => 'OpenAI project API keys (sk-proj-...) are not supported for API access. Use a personal API key from https://platform.openai.com/api-keys.'];
      }

      // Log the first 8 chars of the key for debugging (never log the full key!)
      \Drupal::logger('dataset_upload')->notice('Using OpenAI API key prefix: @prefix', [
        '@prefix' => substr($api_key, 0, 8) . '...'
      ]);

      $response = $this->httpClient->post('https://api.openai.com/v1/chat/completions', [
        'headers' => [
          'Authorization' => 'Bearer ' . $api_key,
          'Content-Type' => 'application/json',
        ],
        'json' => [
          'model' => 'gpt-3.5-turbo',
          'messages' => [
            ['role' => 'user', 'content' => $prompt],
          ],
        ],
      ]);
      $data = json_decode($response->getBody(), TRUE);
      $reply = $data['choices'][0]['message']['content'] ?? '{}';
      return json_decode($reply, TRUE);
    }
    catch (\GuzzleHttp\Exception\ClientException $e) {
      $body = (string) $e->getResponse()->getBody();
      \Drupal::logger('dataset_upload')->error('OpenAI API error: @msg', ['@msg' => $body]);
      return ['error' => 'OpenAI API error: ' . $body];
    }
    catch (\Exception $e) {
      \Drupal::logger('dataset_upload')->error('AI metadata generation failed: @msg', ['@msg' => $e->getMessage()]);
      return ['error' => 'AI metadata generation failed: ' . $e->getMessage()];
    }
  }

  protected function convertSampleToText(array $rows): string {
    $lines = [];
    foreach ($rows as $row) {
      $lines[] = implode(", ", $row);
    }
    return implode("\n", $lines);
  }
}
