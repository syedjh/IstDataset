<?php

namespace Drupal\dataset_upload\Entity;

use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;

/**
 * Defines the Dataset metadata entity.
 *
 * @ContentEntityType(
 *   id = "dataset_metadata",
 *   label = @Translation("Dataset Metadata"),
 *   base_table = "dataset_metadata",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "file_name",
 *     "langcode" = "langcode",
 *     "uuid" = "uuid",
 *     "revision" = "revision_id"
 *   },
 *   revision_table = "dataset_metadata_revision",
 *   revision_data_table = "dataset_metadata_field_revision",
 *   admin_permission = "administer site configuration",
 *   handlers = {
 *     "storage_schema" = "Drupal\Core\Entity\Sql\SqlContentEntityStorageSchema",
 *   },
 *   translatable = TRUE,
 *   revisionable = TRUE
 * )
 */
class DatasetMetadata extends ContentEntityBase {

  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {
    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['file_name'] = BaseFieldDefinition::create('string')
      ->setLabel(t('File Name'))
      ->setRequired(TRUE)
      ->setTranslatable(TRUE);

    $fields['file_size'] = BaseFieldDefinition::create('string')
      ->setLabel(t('File Size (KB)'))
      ->setTranslatable(TRUE);

    $fields['columns'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Column Names'))
      ->setTranslatable(TRUE);

    $fields['rows'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Number of Rows'));

    $fields['status'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Status'));

    $fields['title'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Title'))
      ->setTranslatable(TRUE);

    $fields['description'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Description'))
      ->setTranslatable(TRUE);

    $fields['tags'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Tags'))
      ->setTranslatable(TRUE);

    $fields['categories'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Categories'))
      ->setTranslatable(TRUE);

    // Required for translation support.
    $fields['langcode'] = BaseFieldDefinition::create('language')
      ->setLabel(t('Language'))
      ->setTranslatable(TRUE);

    // Required for revision support.
    $fields['revision_id'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Revision ID'))
      ->setReadOnly(TRUE);

    $fields['uuid'] = BaseFieldDefinition::create('uuid')
      ->setLabel(t('UUID'))
      ->setReadOnly(TRUE);

    return $fields;
  }
}
