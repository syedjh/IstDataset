<?php

namespace Drupal\Tests\dataset_upload\Kernel;

use Drupal\KernelTests\KernelTestBase;
use Drupal\dataset_upload\Service\AIMetadataService;

class AIMetadataServiceTest extends KernelTestBase {

  protected static $modules = ['dataset_upload', 'system'];

  public function testGenerateMetadata() {
    $service = \Drupal::service('dataset_upload.ai_metadata');
    $sample = [['Name', 'Age'], ['Ali', '30'], ['Sara', '25']];
    $result = $service->generateMetadata($sample);
    $this->assertIsArray($result);
    $this->assertArrayHasKey('en', $result);
    $this->assertArrayHasKey('ar', $result);
  }
}
