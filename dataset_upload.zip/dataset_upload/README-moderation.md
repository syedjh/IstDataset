# Dataset Upload: Moderation & Review System

## Architecture
- Uses Drupal Content Moderation for workflow (Draft, Needs Review, Published, Archived)
- Dataset Supervisor role can review, approve, or request edits
- DatasetMetadata entity is revisionable and translatable
- Dashboard built with Views for filtering/searching datasets

## Key Features
- Drag-and-drop upload, AI metadata, and moderation workflow
- Supervisor review UI at `/admin/content/dataset-dashboard`
- Revision tracking and moderation state per dataset

## Permissions
- Dataset Supervisor: can review, publish, archive, and revert datasets

## Extending
- Add more workflow states/transitions in `workflow.workflow.dataset_moderation.yml`
- Add more dashboard filters via Views UI

## Deployment
- Import config: `drush cim`
- Assign supervisor role to users as needed
